package com.antisaint.fretwork;

import android.app.Activity;
import android.content.Intent;
import android.graphics.Color;
import android.graphics.Typeface;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.view.Gravity;
import android.view.View;
import android.webkit.CookieManager;
import android.webkit.URLUtil;
import android.webkit.WebResourceRequest;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.ProgressBar;
import android.widget.TextView;
import android.widget.Toast;
import java.io.File;
import java.io.FileOutputStream;

/** GProTab inside Fretwork. Tapping Download on a song sends the file straight into the app. */
public class BrowseActivity extends Activity {
  WebView web;
  TextView title;
  ProgressBar spin;
  final Handler ui = new Handler(Looper.getMainLooper());
  boolean busy = false;

  @Override protected void onCreate(Bundle saved) {
    super.onCreate(saved);
    float d = getResources().getDisplayMetrics().density;
    LinearLayout root = new LinearLayout(this);
    root.setOrientation(LinearLayout.VERTICAL);
    root.setBackgroundColor(0xFF0E0A09);

    LinearLayout bar = new LinearLayout(this);
    bar.setOrientation(LinearLayout.HORIZONTAL);
    bar.setGravity(Gravity.CENTER_VERTICAL);
    bar.setPadding((int) (8 * d), (int) (6 * d), (int) (8 * d), (int) (6 * d));
    bar.setBackgroundColor(0xFF1A1311);

    Button back = new Button(this);
    back.setText("‹ Fretwork");
    back.setAllCaps(false);
    back.setTextColor(0xFFF2B35B);
    back.setBackgroundColor(Color.TRANSPARENT);
    back.setOnClickListener(v -> finish());
    bar.addView(back);

    title = new TextView(this);
    title.setText("GProTab · tap Download on a song");
    title.setTextColor(0xFFD9CFC7);
    title.setTextSize(13);
    title.setSingleLine(true);
    title.setTypeface(Typeface.DEFAULT_BOLD);
    LinearLayout.LayoutParams tp = new LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f);
    bar.addView(title, tp);

    spin = new ProgressBar(this);
    spin.setVisibility(View.GONE);
    bar.addView(spin, new LinearLayout.LayoutParams((int) (28 * d), (int) (28 * d)));
    root.addView(bar);

    web = new WebView(this);
    root.addView(web, new LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, 0, 1f));
    setContentView(root);

    WebSettings s = web.getSettings();
    s.setJavaScriptEnabled(true);
    s.setDomStorageEnabled(true);
    s.setSupportMultipleWindows(false);
    CookieManager.getInstance().setAcceptCookie(true);
    CookieManager.getInstance().setAcceptThirdPartyCookies(web, true);
    Net.userAgent = s.getUserAgentString();

    web.setWebViewClient(new WebViewClient() {
      @Override public boolean shouldOverrideUrlLoading(WebView v, WebResourceRequest req) {
        String u = req.getUrl().toString();
        if (u.contains("?download") || u.contains("&download")) { grab(u, null, null); return true; }
        return false;
      }
      @Override public void onPageFinished(WebView v, String url) {
        String t = v.getTitle();
        if (t != null && !t.isEmpty()) title.setText(t);
      }
    });
    web.setDownloadListener((url, ua, disposition, mime, length) -> grab(url, disposition, mime));

    String start = getIntent().getStringExtra("url");
    if (saved != null) web.restoreState(saved);
    else web.loadUrl(start != null ? start : "https://gprotab.net/");
  }

  void grab(final String url, final String disposition, final String mime) {
    if (busy) return;
    busy = true;
    spin.setVisibility(View.VISIBLE);
    title.setText("Getting the song…");
    final String referer = web.getUrl();
    new Thread(() -> {
      try {
        Net.Result r = Net.get(url, referer);
        String name = URLUtil.guessFileName(r.finalUrl, r.disposition != null ? r.disposition : disposition, r.mime != null ? r.mime : mime);
        if (name == null || name.endsWith(".bin")) name = songName(url) + ".gp";
        File f = new File(getCacheDir(), "incoming-" + System.currentTimeMillis());
        FileOutputStream out = new FileOutputStream(f);
        out.write(r.body);
        out.close();
        final String finalName = name;
        ui.post(() -> {
          Intent res = new Intent();
          res.putExtra("path", f.getAbsolutePath());
          res.putExtra("name", finalName);
          setResult(RESULT_OK, res);
          finish();
        });
      } catch (final Exception e) {
        ui.post(() -> {
          busy = false;
          spin.setVisibility(View.GONE);
          title.setText("GProTab · tap Download on a song");
          Toast.makeText(this, "Couldn't get that file: " + e.getMessage(), Toast.LENGTH_LONG).show();
        });
      }
    }).start();
  }

  static String songName(String url) {
    try {
      String p = android.net.Uri.parse(url).getPath();
      String[] parts = p.split("/");
      if (parts.length >= 2) return parts[parts.length - 1].replace('-', ' ') + " - " + parts[parts.length - 2].replace('-', ' ');
    } catch (Exception ignored) { }
    return "song";
  }

  @Override protected void onSaveInstanceState(Bundle out) { super.onSaveInstanceState(out); web.saveState(out); }

  @Override public void onBackPressed() {
    if (web.canGoBack()) web.goBack();
    else super.onBackPressed();
  }

  @Override protected void onPause() { super.onPause(); CookieManager.getInstance().flush(); }
}
