package com.antisaint.fretwork;

import android.app.Activity;
import android.content.Intent;
import android.graphics.Color;
import android.graphics.Typeface;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.view.Gravity;
import android.view.View;
import android.webkit.CookieManager;
import android.webkit.URLUtil;
import android.webkit.WebResourceRequest;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.ProgressBar;
import android.widget.TextView;
import android.widget.Toast;
import java.io.File;
import java.io.FileOutputStream;

/** GProTab inside Fretwork. Tapping Download on a song sends the file straight into the app. */
public class BrowseActivity extends Activity {
  WebView web;
  TextView title;
  ProgressBar spin;
  final Handler ui = new Handler(Looper.getMainLooper());
  boolean busy = false;
  boolean ug = false;
  Button send;

  @Override protected void onCreate(Bundle saved) {
    super.onCreate(saved);
    float d = getResources().getDisplayMetrics().density;
    LinearLayout root = new LinearLayout(this);
    root.setOrientation(LinearLayout.VERTICAL);
    root.setBackgroundColor(0xFF000000);

    LinearLayout bar = new LinearLayout(this);
    bar.setOrientation(LinearLayout.HORIZONTAL);
    bar.setGravity(Gravity.CENTER_VERTICAL);
    bar.setPadding((int) (8 * d), (int) (6 * d), (int) (8 * d), (int) (6 * d));
    bar.setBackgroundColor(0xFF0A0A0A);

    Button back = new Button(this);
    back.setText("‹ Fretwork");
    back.setAllCaps(false);
    back.setTextColor(0xFFF2B35B);
    back.setBackgroundColor(Color.TRANSPARENT);
    back.setOnClickListener(v -> finish());
    bar.addView(back);

    title = new TextView(this);
    title.setText("GProTab · tap Download on a song");
    title.setTextColor(0xFFD9CFC7);
    title.setTextSize(13);
    title.setSingleLine(true);
    title.setTypeface(Typeface.DEFAULT_BOLD);
    LinearLayout.LayoutParams tp = new LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f);
    bar.addView(title, tp);

    /* Ultimate Guitar: you pick the tab, then one tap sends what you're looking at to Fretwork */
    send = new Button(this);
    send.setText("Send to Fretwork");
    send.setAllCaps(false);
    send.setTextColor(0xFF000000);
    send.setTypeface(Typeface.DEFAULT_BOLD);
    android.graphics.drawable.GradientDrawable pill = new android.graphics.drawable.GradientDrawable();
    pill.setColor(0xFFF2B35B); pill.setCornerRadius(40 * d);
    send.setBackground(pill);
    send.setPadding((int) (14 * d), 0, (int) (14 * d), 0);
    send.setVisibility(View.GONE);
    send.setOnClickListener(v -> sendTab());
    bar.addView(send, new LinearLayout.LayoutParams(LinearLayout.LayoutParams.WRAP_CONTENT, (int) (40 * d)));

    spin = new ProgressBar(this);
    spin.setVisibility(View.GONE);
    bar.addView(spin, new LinearLayout.LayoutParams((int) (28 * d), (int) (28 * d)));
    root.addView(bar);

    web = new WebView(this);
    root.addView(web, new LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, 0, 1f));
    setContentView(root);

    WebSettings s = web.getSettings();
    s.setJavaScriptEnabled(true);
    s.setDomStorageEnabled(true);
    s.setSupportMultipleWindows(false);
    CookieManager.getInstance().setAcceptCookie(true);
    CookieManager.getInstance().setAcceptThirdPartyCookies(web, true);
    Net.userAgent = s.getUserAgentString();

    web.setWebViewClient(new WebViewClient() {
      @Override public boolean shouldOverrideUrlLoading(WebView v, WebResourceRequest req) {
        String u = req.getUrl().toString();
        if (u.contains("?download") || u.contains("&download")) { grab(u, null, null); return true; }
        return false;
      }
      @Override public void onPageFinished(WebView v, String url) {
        String t = v.getTitle();
        if (ug) { boolean tabPage = url != null && url.contains("/tab/"); send.setVisibility(tabPage ? View.VISIBLE : View.GONE); title.setText(tabPage ? "Looks right? Tap Send" : "Ultimate Guitar · open a tab"); return; }
        if (t != null && !t.isEmpty()) title.setText(t);
      }
    });
    web.setDownloadListener((url, ua, disposition, mime, length) -> grab(url, disposition, mime));

    String start = getIntent().getStringExtra("url");
    ug = start != null && start.contains("ultimate-guitar.com");
    if (ug) title.setText("Ultimate Guitar · open a tab");
    if (saved != null) web.restoreState(saved);
    else web.loadUrl(start != null ? start : "https://gprotab.net/");
  }

  void grab(final String url, final String disposition, final String mime) {
    if (busy) return;
    busy = true;
    spin.setVisibility(View.VISIBLE);
    title.setText("Getting the song…");
    final String referer = web.getUrl();
    new Thread(() -> {
      try {
        Net.Result r = Net.get(url, referer);
        String name = URLUtil.guessFileName(r.finalUrl, r.disposition != null ? r.disposition : disposition, r.mime != null ? r.mime : mime);
        if (name == null || name.endsWith(".bin")) name = songName(url) + ".gp";
        File f = new File(getCacheDir(), "incoming-" + System.currentTimeMillis());
        FileOutputStream out = new FileOutputStream(f);
        out.write(r.body);
        out.close();
        final String finalName = name;
        ui.post(() -> {
          Intent res = new Intent();
          res.putExtra("path", f.getAbsolutePath());
          res.putExtra("name", finalName);
          setResult(RESULT_OK, res);
          finish();
        });
      } catch (final Exception e) {
        ui.post(() -> {
          busy = false;
          spin.setVisibility(View.GONE);
          title.setText("GProTab · tap Download on a song");
          Toast.makeText(this, "Couldn't get that file: " + e.getMessage(), Toast.LENGTH_LONG).show();
        });
      }
    }).start();
  }

  static final String GRAB_JS = "(function(){var o={url:location.href,title:'',artist:'',tuning:'',capo:0,type:'',text:''};"
      + "try{var st=document.querySelector('.js-store');var d=st?JSON.parse(st.getAttribute('data-content')):null;var pd=d&&d.store&&d.store.page&&d.store.page.data;"
      + "var tv=pd&&pd.tab_view;var tb=pd&&pd.tab;if(tv&&tv.wiki_tab)o.text=tv.wiki_tab.content||'';if(tb){o.title=tb.song_name||'';o.artist=tb.artist_name||'';o.type=tb.type||'';}"
      + "var mt=tv&&tv.meta;if(mt){if(mt.tuning)o.tuning=mt.tuning.value||mt.tuning.name||'';if(mt.capo)o.capo=mt.capo;}}catch(e){}"
      + "if(!o.text){var pre=document.querySelectorAll('pre');for(var i=0;i<pre.length;i++){if(pre[i].innerText.length>o.text.length)o.text=pre[i].innerText;}}"
      + "if(!o.text){var c=document.querySelector('code');if(c)o.text=c.innerText;}"
      + "if(!o.text)o.text=document.body.innerText;"
      + "if(!o.title){var h=document.querySelector('h1');o.title=(h?h.innerText:document.title).replace(/\\s*(chords|tab|tabs|bass|ukulele)\\s*(by.*)?$/i,'');}"
      + "if(!o.artist){var a=document.querySelector('a[href*=\\'/artist/\\']');if(a)o.artist=a.innerText;}"
      + "return JSON.stringify(o);})()";
  void sendTab() {
    spin.setVisibility(View.VISIBLE);
    web.evaluateJavascript(GRAB_JS, value -> {
      spin.setVisibility(View.GONE);
      String json = null;
      try { json = new org.json.JSONArray("[" + value + "]").getString(0); } catch (Exception e) { }
      if (json == null || json.length() < 40) { Toast.makeText(this, "Couldn't read the tab on this page. Open the tab itself, then tap Send.", Toast.LENGTH_LONG).show(); return; }
      Intent res = new Intent();
      res.putExtra("tabjson", json);
      setResult(RESULT_OK, res);
      finish();
    });
  }

  static String songName(String url) {
    try {
      String p = android.net.Uri.parse(url).getPath();
      String[] parts = p.split("/");
      if (parts.length >= 2) return parts[parts.length - 1].replace('-', ' ') + " - " + parts[parts.length - 2].replace('-', ' ');
    } catch (Exception ignored) { }
    return "song";
  }

  @Override protected void onSaveInstanceState(Bundle out) { super.onSaveInstanceState(out); web.saveState(out); }

  @Override public void onBackPressed() {
    if (web.canGoBack()) web.goBack();
    else super.onBackPressed();
  }

  @Override protected void onPause() { super.onPause(); CookieManager.getInstance().flush(); }
}
