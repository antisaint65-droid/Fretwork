package com.antisaint.fretwork;

import android.Manifest;
import android.app.Activity;
import android.content.ActivityNotFoundException;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.database.Cursor;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.provider.OpenableColumns;
import android.util.Base64;
import android.webkit.JavascriptInterface;
import android.webkit.PermissionRequest;
import android.webkit.ValueCallback;
import android.webkit.WebChromeClient;
import android.webkit.WebResourceRequest;
import android.webkit.WebResourceResponse;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import org.json.JSONObject;

public class MainActivity extends Activity {
  static final String HOST = "appassets.androidplatform.net";
  static final String HOME = "https://" + HOST + "/index.html";
  static final int REQ_FILE = 11, REQ_BROWSE = 12, REQ_MIC = 13;

  WebView web;
  boolean pageReady = false;
  final List<String> pendingJs = new ArrayList<>();
  final Handler ui = new Handler(Looper.getMainLooper());
  ValueCallback<Uri[]> fileCallback;
  PermissionRequest pendingPermission;

  @Override protected void onCreate(Bundle saved) {
    super.onCreate(saved);
    web = new WebView(this);
    setContentView(web);
    WebSettings s = web.getSettings();
    s.setJavaScriptEnabled(true);
    s.setDomStorageEnabled(true);
    s.setDatabaseEnabled(true);
    s.setMediaPlaybackRequiresUserGesture(false);
    s.setAllowFileAccess(false);
    s.setAllowContentAccess(true);
    s.setTextZoom(100);
    Net.userAgent = s.getUserAgentString();
    web.setBackgroundColor(0xFF0E0A09);
    web.addJavascriptInterface(new Bridge(), "FretworkNative");

    web.setWebViewClient(new WebViewClient() {
      @Override public WebResourceResponse shouldInterceptRequest(WebView v, WebResourceRequest req) {
        Uri u = req.getUrl();
        if (!HOST.equals(u.getHost())) return null;
        String path = u.getPath();
        if (path == null || path.equals("/") || path.isEmpty()) path = "/index.html";
        try {
          InputStream in = getAssets().open("www" + path);
          WebResourceResponse r = new WebResourceResponse(mimeOf(path), "utf-8", in);
          Map<String, String> h = new HashMap<>();
          h.put("Cache-Control", "no-cache");
          h.put("Access-Control-Allow-Origin", "*");
          r.setResponseHeaders(h);
          return r;
        } catch (Exception e) {
          return new WebResourceResponse("text/plain", "utf-8", 404, "Not Found", new HashMap<String, String>(), new java.io.ByteArrayInputStream(new byte[0]));
        }
      }
      @Override public boolean shouldOverrideUrlLoading(WebView v, WebResourceRequest req) {
        Uri u = req.getUrl();
        String host = u.getHost() == null ? "" : u.getHost();
        if (HOST.equals(host)) return false;
        if (host.endsWith("gprotab.net")) { openBrowse(u.toString()); return true; }
        try { startActivity(new Intent(Intent.ACTION_VIEW, u)); } catch (ActivityNotFoundException e) { }
        return true;
      }
      @Override public void onPageFinished(WebView v, String url) {
        pageReady = true;
        for (String js : pendingJs) web.evaluateJavascript(js, null);
        pendingJs.clear();
      }
    });

    web.setWebChromeClient(new WebChromeClient() {
      @Override public void onPermissionRequest(final PermissionRequest request) {
        ui.post(() -> {
          boolean wantsMic = false;
          for (String r : request.getResources()) if (PermissionRequest.RESOURCE_AUDIO_CAPTURE.equals(r)) wantsMic = true;
          if (!wantsMic) { request.deny(); return; }
          if (checkSelfPermission(Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED) {
            request.grant(new String[]{PermissionRequest.RESOURCE_AUDIO_CAPTURE});
          } else {
            pendingPermission = request;
            requestPermissions(new String[]{Manifest.permission.RECORD_AUDIO}, REQ_MIC);
          }
        });
      }
      @Override public boolean onShowFileChooser(WebView v, ValueCallback<Uri[]> cb, FileChooserParams p) {
        if (fileCallback != null) fileCallback.onReceiveValue(null);
        fileCallback = cb;
        Intent i = new Intent(Intent.ACTION_GET_CONTENT);
        i.addCategory(Intent.CATEGORY_OPENABLE);
        i.setType("*/*");
        try { startActivityForResult(Intent.createChooser(i, "Choose a tab file"), REQ_FILE); }
        catch (ActivityNotFoundException e) { fileCallback = null; return false; }
        return true;
      }
    });

    if (saved != null) web.restoreState(saved);
    else web.loadUrl(HOME);
    handleIntent(getIntent());
  }

  static String mimeOf(String p) {
    String l = p.toLowerCase();
    if (l.endsWith(".html")) return "text/html";
    if (l.endsWith(".js")) return "application/javascript";
    if (l.endsWith(".json") || l.endsWith(".webmanifest")) return "application/json";
    if (l.endsWith(".png")) return "image/png";
    if (l.endsWith(".svg")) return "image/svg+xml";
    if (l.endsWith(".css")) return "text/css";
    return "application/octet-stream";
  }

  void runJs(String js) {
    ui.post(() -> { if (pageReady) web.evaluateJavascript(js, null); else pendingJs.add(js); });
  }

  void openBrowse(String url) {
    Intent i = new Intent(this, BrowseActivity.class);
    i.putExtra("url", url);
    startActivityForResult(i, REQ_BROWSE);
  }

  @Override protected void onNewIntent(Intent intent) {
    super.onNewIntent(intent);
    setIntent(intent);
    handleIntent(intent);
  }

  void handleIntent(Intent intent) {
    if (intent == null) return;
    String action = intent.getAction();
    Uri uri = null;
    if (Intent.ACTION_VIEW.equals(action)) uri = intent.getData();
    else if (Intent.ACTION_SEND.equals(action)) {
      uri = intent.getParcelableExtra(Intent.EXTRA_STREAM);
      if (uri == null) {
        String text = intent.getStringExtra(Intent.EXTRA_TEXT);
        if (text != null) runJs("window.fretworkOpenText&&window.fretworkOpenText(" + JSONObject.quote(text) + ")");
        return;
      }
    }
    if (uri != null) sendUri(uri);
  }

  void sendUri(final Uri uri) {
    new Thread(() -> {
      try {
        String name = "shared file";
        try (Cursor c = getContentResolver().query(uri, null, null, null, null)) {
          if (c != null && c.moveToFirst()) {
            int idx = c.getColumnIndex(OpenableColumns.DISPLAY_NAME);
            if (idx >= 0) name = c.getString(idx);
          }
        } catch (Exception ignored) { }
        if ("shared file".equals(name) && uri.getLastPathSegment() != null) name = uri.getLastPathSegment();
        InputStream in = getContentResolver().openInputStream(uri);
        byte[] data = readAll(in);
        sendBytes(name, data);
      } catch (Exception e) { }
    }).start();
  }

  void sendBytes(String name, byte[] data) {
    String b64 = Base64.encodeToString(data, Base64.NO_WRAP);
    runJs("window.fretworkOpenFile&&window.fretworkOpenFile(" + JSONObject.quote(name) + "," + JSONObject.quote(b64) + ")");
  }

  static byte[] readAll(InputStream in) throws Exception {
    ByteArrayOutputStream out = new ByteArrayOutputStream();
    byte[] buf = new byte[16384];
    int n;
    while ((n = in.read(buf)) > 0) out.write(buf, 0, n);
    in.close();
    return out.toByteArray();
  }

  @Override protected void onActivityResult(int req, int res, Intent data) {
    super.onActivityResult(req, res, data);
    if (req == REQ_FILE) {
      if (fileCallback != null) {
        Uri[] r = null;
        if (res == RESULT_OK && data != null && data.getData() != null) r = new Uri[]{data.getData()};
        fileCallback.onReceiveValue(r);
        fileCallback = null;
      }
    } else if (req == REQ_BROWSE && res == RESULT_OK && data != null) {
      final String path = data.getStringExtra("path");
      final String name = data.getStringExtra("name");
      if (path == null) return;
      new Thread(() -> {
        try {
          File f = new File(path);
          byte[] bytes = readAll(new FileInputStream(f));
          f.delete();
          sendBytes(name == null ? "song.gp" : name, bytes);
        } catch (Exception e) { }
      }).start();
    }
  }

  @Override public void onRequestPermissionsResult(int req, String[] perms, int[] results) {
    if (req == REQ_MIC && pendingPermission != null) {
      if (results.length > 0 && results[0] == PackageManager.PERMISSION_GRANTED)
        pendingPermission.grant(new String[]{PermissionRequest.RESOURCE_AUDIO_CAPTURE});
      else pendingPermission.deny();
      pendingPermission = null;
    }
  }

  @Override protected void onSaveInstanceState(Bundle out) {
    super.onSaveInstanceState(out);
    web.saveState(out);
  }

  @Override public void onBackPressed() {
    if (web.canGoBack()) web.goBack();
    else super.onBackPressed();
  }

  @Override protected void onPause() { super.onPause(); android.webkit.CookieManager.getInstance().flush(); }

  /** Lets the app reach websites directly, without the browser's cross-site limits. */
  final class Bridge {
    @JavascriptInterface public void fetch(final String id, final String url) {
      new Thread(() -> {
        try {
          String ref = url.contains("gprotab.net") ? "https://gprotab.net/" : null;
          Net.Result r = Net.get(url, ref);
          runJs("window.__fwNative(" + JSONObject.quote(id) + ",true," + JSONObject.quote(Base64.encodeToString(r.body, Base64.NO_WRAP)) + ")");
        } catch (Exception e) {
          runJs("window.__fwNative(" + JSONObject.quote(id) + ",false," + JSONObject.quote(String.valueOf(e.getMessage())) + ")");
        }
      }).start();
    }
    @JavascriptInterface public boolean isApp() { return true; }
    @JavascriptInterface public void setImmersive(final boolean on) {
      ui.post(() -> {
        android.view.View d = getWindow().getDecorView();
        if (on) d.setSystemUiVisibility(android.view.View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY | android.view.View.SYSTEM_UI_FLAG_FULLSCREEN
            | android.view.View.SYSTEM_UI_FLAG_HIDE_NAVIGATION | android.view.View.SYSTEM_UI_FLAG_LAYOUT_STABLE
            | android.view.View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION | android.view.View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN);
        else d.setSystemUiVisibility(android.view.View.SYSTEM_UI_FLAG_LAYOUT_STABLE);
      });
    }
  }
}
