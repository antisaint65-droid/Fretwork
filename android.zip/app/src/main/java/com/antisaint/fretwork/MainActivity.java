package com.antisaint.fretwork;

import android.Manifest;
import android.app.Activity;
import android.content.ActivityNotFoundException;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.database.Cursor;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.provider.OpenableColumns;
import android.util.Base64;
import android.webkit.JavascriptInterface;
import android.webkit.PermissionRequest;
import android.webkit.ValueCallback;
import android.webkit.WebChromeClient;
import android.webkit.WebResourceRequest;
import android.webkit.WebResourceResponse;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.InputStream;
import java.net.HttpURLConnection;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import org.json.JSONObject;

public class MainActivity extends Activity {
  static final String HOST = "appassets.androidplatform.net";
  static final String HOME = "https://" + HOST + "/index.html";
  static final int REQ_FILE = 11, REQ_BROWSE = 12, REQ_MIC = 13, REQ_CAP = 14, REQ_RECPERM = 15;
  static volatile MainActivity inst;
  JSONObject pendingRec;

  WebView web;
  boolean pageReady = false;
  final List<String> pendingJs = new ArrayList<>();
  final Handler ui = new Handler(Looper.getMainLooper());
  ValueCallback<Uri[]> fileCallback;
  PermissionRequest pendingPermission;
  volatile android.media.session.MediaController current;

  @Override protected void onCreate(Bundle saved) {
    super.onCreate(saved);
    inst = this;
    /* crash report: save what went wrong, so the app can show it (and send it to the lab) next time */
    final Thread.UncaughtExceptionHandler prev = Thread.getDefaultUncaughtExceptionHandler();
    final File crashFile = new File(getFilesDir(), "crash.txt");
    final android.content.Context app = getApplicationContext();
    Thread.setDefaultUncaughtExceptionHandler((th, ex) -> {
      try {
        java.io.StringWriter sw = new java.io.StringWriter(); ex.printStackTrace(new java.io.PrintWriter(sw));
        String txt = new java.util.Date() + "\n" + Build.MANUFACTURER + " " + Build.MODEL + ", Android " + Build.VERSION.RELEASE + " (SDK " + Build.VERSION.SDK_INT + ")\nthread " + th.getName()
            + "\n--- recording steps ---\n" + RecService.trace(app) + "--- error ---\n" + sw;
        save(crashFile, txt.getBytes("UTF-8"));
      } catch (Throwable x) { }
      if (prev != null) prev.uncaughtException(th, ex);
    });
    web = new WebView(this);
    setContentView(web);
    WebSettings s = web.getSettings();
    s.setJavaScriptEnabled(true);
    s.setDomStorageEnabled(true);
    s.setDatabaseEnabled(true);
    s.setMediaPlaybackRequiresUserGesture(false);
    s.setAllowFileAccess(false);
    s.setAllowContentAccess(true);
    s.setTextZoom(100);
    Net.userAgent = s.getUserAgentString();
    web.setBackgroundColor(0xFF000000);
    web.addJavascriptInterface(new Bridge(), "FretworkNative");

    web.setWebViewClient(new WebViewClient() {
      @Override public WebResourceResponse shouldInterceptRequest(WebView v, WebResourceRequest req) {
        Uri u = req.getUrl();
        if (!HOST.equals(u.getHost())) return null;
        String path = u.getPath();
        if (path == null || path.equals("/") || path.isEmpty()) path = "/index.html";
        if (path.startsWith("/__rec/")) {
          File rf = new File(new File(getFilesDir(), "rec"), "latest.m4a");
          try {
            WebResourceResponse r = new WebResourceResponse("audio/mp4", null, new FileInputStream(rf));
            Map<String, String> h = new HashMap<>(); h.put("Cache-Control", "no-store"); r.setResponseHeaders(h); return r;
          } catch (Exception e) { return new WebResourceResponse("text/plain", "utf-8", 404, "Not Found", new HashMap<String, String>(), new java.io.ByteArrayInputStream(new byte[0])); }
        }
        try {
          byte[] body = livePage(path);
          InputStream in = body != null ? new java.io.ByteArrayInputStream(body) : getAssets().open("www" + path);
          WebResourceResponse r = new WebResourceResponse(mimeOf(path), "utf-8", in);
          Map<String, String> h = new HashMap<>();
          h.put("Cache-Control", "no-cache");
          h.put("Access-Control-Allow-Origin", "*");
          r.setResponseHeaders(h);
          return r;
        } catch (Exception e) {
          return new WebResourceResponse("text/plain", "utf-8", 404, "Not Found", new HashMap<String, String>(), new java.io.ByteArrayInputStream(new byte[0]));
        }
      }
      @Override public boolean shouldOverrideUrlLoading(WebView v, WebResourceRequest req) {
        Uri u = req.getUrl();
        String host = u.getHost() == null ? "" : u.getHost();
        if (HOST.equals(host)) return false;
        if (host.endsWith("gprotab.net")) { openBrowse(u.toString()); return true; }
        if (host.endsWith("spotify.com") || host.endsWith("scdn.co") || host.endsWith("spotifycdn.com")) return false;
        try { startActivity(new Intent(Intent.ACTION_VIEW, u)); } catch (ActivityNotFoundException e) { }
        return true;
      }
      @Override public void onPageFinished(WebView v, String url) {
        pageReady = true;
        for (String js : pendingJs) web.evaluateJavascript(js, null);
        pendingJs.clear();
      }
    });

    web.setWebChromeClient(new WebChromeClient() {
      @Override public void onPermissionRequest(final PermissionRequest request) {
        ui.post(() -> {
          boolean wantsMic = false;
          for (String r : request.getResources()) if (PermissionRequest.RESOURCE_AUDIO_CAPTURE.equals(r)) wantsMic = true;
          if (!wantsMic) { request.deny(); return; }
          if (checkSelfPermission(Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED) {
            request.grant(new String[]{PermissionRequest.RESOURCE_AUDIO_CAPTURE});
          } else {
            pendingPermission = request;
            requestPermissions(new String[]{Manifest.permission.RECORD_AUDIO}, REQ_MIC);
          }
        });
      }
      @Override public boolean onShowFileChooser(WebView v, ValueCallback<Uri[]> cb, FileChooserParams p) {
        if (fileCallback != null) fileCallback.onReceiveValue(null);
        fileCallback = cb;
        Intent i = new Intent(Intent.ACTION_GET_CONTENT);
        i.addCategory(Intent.CATEGORY_OPENABLE);
        i.setType("*/*");
        try { startActivityForResult(Intent.createChooser(i, "Choose a tab file"), REQ_FILE); }
        catch (ActivityNotFoundException e) { fileCallback = null; return false; }
        return true;
      }
    });

    if (saved != null) web.restoreState(saved);
    else web.loadUrl(HOME);
    handleIntent(getIntent());
  }


  /* Live updates: the app's pages come from the website, so every phone gets each update on its next launch.
     The newest copy is saved on the phone for offline use; the copy built into the app is the last resort.
     Pages keep this app's own address, so saved songs and settings stay where they are. */
  static final String LIVE = "https://antisaint65-droid.github.io/Fretwork";
  final java.util.Set<String> refreshed = java.util.Collections.synchronizedSet(new java.util.HashSet<String>());
  File liveFile(String path) { return new File(new File(getFilesDir(), "live"), path.replaceAll("[^A-Za-z0-9._/-]", "_").replace("..", "_")); }
  static byte[] download(String address, int timeoutMs) {
    HttpURLConnection c = null;
    try {
      c = (HttpURLConnection) new java.net.URL(address).openConnection();
      c.setConnectTimeout(timeoutMs); c.setReadTimeout(timeoutMs * 2); c.setUseCaches(false);
      c.setRequestProperty("Cache-Control", "no-cache");
      if (c.getResponseCode() != 200) return null;
      InputStream in = c.getInputStream(); ByteArrayOutputStream out = new ByteArrayOutputStream();
      byte[] buf = new byte[16384]; int n; while ((n = in.read(buf)) > 0) out.write(buf, 0, n); in.close();
      return out.toByteArray();
    } catch (Exception e) { return null; } finally { if (c != null) c.disconnect(); }
  }
  static void save(File f, byte[] b) {
    try { f.getParentFile().mkdirs(); File t = new File(f.getPath() + ".tmp"); java.io.FileOutputStream o = new java.io.FileOutputStream(t); o.write(b); o.close(); t.renameTo(f); } catch (Exception e) { }
  }
  static byte[] read(File f) {
    try { FileInputStream in = new FileInputStream(f); ByteArrayOutputStream out = new ByteArrayOutputStream(); byte[] buf = new byte[16384]; int n; while ((n = in.read(buf)) > 0) out.write(buf, 0, n); in.close(); return out.toByteArray(); } catch (Exception e) { return null; }
  }
  byte[] livePage(String path) {
    File f = liveFile(path);
    boolean page = path.endsWith(".html") || path.endsWith(".webmanifest") || path.endsWith(".js");
    if (page) {
      if (refreshed.add(path)) {  /* once per launch: fetch the newest copy */
        byte[] b = download(LIVE + path + "?t=" + System.currentTimeMillis(), 5000);
        if (b != null && b.length > 200 && (!path.endsWith(".html") || new String(b, 0, Math.min(b.length, 4000), java.nio.charset.StandardCharsets.UTF_8).contains("Fretwork"))) { save(f, b); return b; }
      }
      return f.exists() ? read(f) : null;
    }
    /* fonts, images: keep the saved copy; fetch once if we don't have it */
    if (f.exists()) return read(f);
    try { getAssets().open("www" + path).close(); return null; } catch (Exception e) { }
    byte[] b = download(LIVE + path, 8000);
    if (b != null) save(f, b);
    return b;
  }

  static String mimeOf(String p) {
    String l = p.toLowerCase();
    if (l.endsWith(".html")) return "text/html";
    if (l.endsWith(".js")) return "application/javascript";
    if (l.endsWith(".json") || l.endsWith(".webmanifest")) return "application/json";
    if (l.endsWith(".png")) return "image/png";
    if (l.endsWith(".svg")) return "image/svg+xml";
    if (l.endsWith(".jpg") || l.endsWith(".jpeg")) return "image/jpeg";
    if (l.endsWith(".css")) return "text/css";
    if (l.endsWith(".ttf")) return "font/ttf";
    if (l.endsWith(".woff2")) return "font/woff2";
    return "application/octet-stream";
  }

  void runJs(String js) {
    ui.post(() -> { if (pageReady) web.evaluateJavascript(js, null); else pendingJs.add(js); });
  }

  void openBrowse(String url) {
    Intent i = new Intent(this, BrowseActivity.class);
    i.putExtra("url", url);
    startActivityForResult(i, REQ_BROWSE);
  }

  @Override protected void onNewIntent(Intent intent) {
    super.onNewIntent(intent);
    setIntent(intent);
    handleIntent(intent);
  }

  void handleIntent(Intent intent) {
    if (intent == null) return;
    if (intent.getBooleanExtra("recDone", false)) { intent.removeExtra("recDone"); runJs("window.fretworkRecDone&&window.fretworkRecDone()"); return; }
    String action = intent.getAction();
    Uri uri = null;
    if (Intent.ACTION_VIEW.equals(action)) uri = intent.getData();
    else if (Intent.ACTION_SEND.equals(action)) {
      uri = intent.getParcelableExtra(Intent.EXTRA_STREAM);
      if (uri == null) {
        String text = intent.getStringExtra(Intent.EXTRA_TEXT);
        if (text != null) runJs("window.fretworkOpenText&&window.fretworkOpenText(" + JSONObject.quote(text) + ")");
        return;
      }
    }
    if (uri != null) sendUri(uri);
  }

  void sendUri(final Uri uri) {
    new Thread(() -> {
      try {
        String name = "shared file";
        try (Cursor c = getContentResolver().query(uri, null, null, null, null)) {
          if (c != null && c.moveToFirst()) {
            int idx = c.getColumnIndex(OpenableColumns.DISPLAY_NAME);
            if (idx >= 0) name = c.getString(idx);
          }
        } catch (Exception ignored) { }
        if ("shared file".equals(name) && uri.getLastPathSegment() != null) name = uri.getLastPathSegment();
        InputStream in = getContentResolver().openInputStream(uri);
        byte[] data = readAll(in);
        sendBytes(name, data);
      } catch (Exception e) { }
    }).start();
  }

  void sendBytes(String name, byte[] data) {
    String b64 = Base64.encodeToString(data, Base64.NO_WRAP);
    runJs("window.fretworkOpenFile&&window.fretworkOpenFile(" + JSONObject.quote(name) + "," + JSONObject.quote(b64) + ")");
  }

  static byte[] readAll(InputStream in) throws Exception {
    ByteArrayOutputStream out = new ByteArrayOutputStream();
    byte[] buf = new byte[16384];
    int n;
    while ((n = in.read(buf)) > 0) out.write(buf, 0, n);
    in.close();
    return out.toByteArray();
  }

  @Override protected void onDestroy() { if (inst == this) inst = null; super.onDestroy(); }

  /* ---------- record YouTube's sound for the lab ---------- */
  void recBegin() {
    if (pendingRec == null) return;
    RecService.mark(this, "checking permissions");
    java.util.List<String> need = new ArrayList<>();
    if (checkSelfPermission(Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) need.add(Manifest.permission.RECORD_AUDIO);
    if (Build.VERSION.SDK_INT >= 33 && checkSelfPermission("android.permission.POST_NOTIFICATIONS") != PackageManager.PERMISSION_GRANTED) need.add("android.permission.POST_NOTIFICATIONS");
    if (!need.isEmpty()) { requestPermissions(need.toArray(new String[0]), REQ_RECPERM); return; }
    try {
      android.media.projection.MediaProjectionManager mpm = (android.media.projection.MediaProjectionManager) getSystemService(MEDIA_PROJECTION_SERVICE);
      Intent ask = Build.VERSION.SDK_INT >= 34 ? mpm.createScreenCaptureIntent(android.media.projection.MediaProjectionConfig.createConfigForDefaultDisplay()) : mpm.createScreenCaptureIntent();
      RecService.mark(this, "asking Android (Start now)");
      startActivityForResult(ask, REQ_CAP);
    } catch (Exception e) { recFail("Couldn't ask Android to record: " + e.getMessage()); }
  }
  void recFail(String why) {
    pendingRec = null;
    RecService.result = RecService.err(why);
    runJs("window.fretworkRecDone&&window.fretworkRecDone()");
  }
  void recGo(int code, Intent data) {
    JSONObject o = pendingRec; pendingRec = null;
    if (o == null) return;
    Intent si = new Intent(this, RecService.class).putExtra("code", code).putExtra("data", data)
        .putExtra("dur", o.optLong("dur", 0)).putExtra("title", o.optString("title")).putExtra("resume", o.optBoolean("resume"));
    try { RecService.mark(this, "starting recorder service"); if (Build.VERSION.SDK_INT >= 26) startForegroundService(si); else startService(si); }
    catch (Exception e) { RecService.mark(this, "service start FAILED: " + e); recFail("Couldn't start recording: " + e.getMessage()); return; }
    final String url = o.optString("url");
    ui.postDelayed(() -> openPanel(url), 700);
  }
  /* YouTube opens in a Chrome panel that sits inside Fretwork (a custom tab); ✕ comes straight back here */
  void openPanel(String url) {
    RecService.mark(this, "opening YouTube panel");
    Intent i = new Intent(Intent.ACTION_VIEW, Uri.parse(url));
    Bundle b = new Bundle(); b.putBinder("android.support.customtabs.extra.SESSION", null); i.putExtras(b);
    i.putExtra("android.support.customtabs.extra.TOOLBAR_COLOR", 0xFF0A0A0A);
    i.putExtra("android.support.customtabs.extra.TITLE_VISIBILITY", 1);
    i.putExtra("androidx.browser.customtabs.extra.SHARE_STATE", 2);
    i.putExtra("androidx.browser.customtabs.extra.COLOR_SCHEME", 2);
    for (String p : new String[]{"com.android.chrome", "com.chrome.beta", "com.sec.android.app.sbrowser", "com.microsoft.emmx", "com.brave.browser"}) {
      try { getPackageManager().getPackageInfo(p, 0); i.setPackage(p); break; } catch (Exception e) { }
    }
    try { startActivity(i); } catch (Exception e) { try { i.setPackage(null); startActivity(i); } catch (Exception e2) { } }
  }

  @Override protected void onActivityResult(int req, int res, Intent data) {
    super.onActivityResult(req, res, data);
    if (req == REQ_CAP) {
      RecService.mark(this, "Start now answer " + res + ", data " + (data != null));
      if (res == RESULT_OK && data != null) recGo(res, data);
      else recFail("denied");
      return;
    }
    if (req == REQ_FILE) {
      if (fileCallback != null) {
        Uri[] r = null;
        if (res == RESULT_OK && data != null && data.getData() != null) r = new Uri[]{data.getData()};
        fileCallback.onReceiveValue(r);
        fileCallback = null;
      }
    } else if (req == REQ_BROWSE && res == RESULT_OK && data != null) {
      final String path = data.getStringExtra("path");
      final String name = data.getStringExtra("name");
      if (path == null) return;
      new Thread(() -> {
        try {
          File f = new File(path);
          byte[] bytes = readAll(new FileInputStream(f));
          f.delete();
          sendBytes(name == null ? "song.gp" : name, bytes);
        } catch (Exception e) { }
      }).start();
    }
  }

  @Override public void onRequestPermissionsResult(int req, String[] perms, int[] results) {
    if (req == REQ_RECPERM) {
      RecService.mark(this, "permission answers " + java.util.Arrays.toString(results));
      if (checkSelfPermission(Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED) recBegin();
      else recFail("mic");
      return;
    }
    if (req == REQ_MIC && pendingPermission != null) {
      if (results.length > 0 && results[0] == PackageManager.PERMISSION_GRANTED)
        pendingPermission.grant(new String[]{PermissionRequest.RESOURCE_AUDIO_CAPTURE});
      else pendingPermission.deny();
      pendingPermission = null;
    }
  }

  @Override protected void onSaveInstanceState(Bundle out) {
    super.onSaveInstanceState(out);
    web.saveState(out);
  }

  @Override public void onBackPressed() {
    if (web.canGoBack()) web.goBack();
    else super.onBackPressed();
  }

  @Override protected void onPause() { super.onPause(); android.webkit.CookieManager.getInstance().flush(); }

  /** Lets the app reach websites directly, without the browser's cross-site limits. */
  final class Bridge {
    @JavascriptInterface public void fetch(final String id, final String url) {
      new Thread(() -> {
        try {
          String ref = url.contains("gprotab.net") ? "https://gprotab.net/" : null;
          Net.Result r = Net.get(url, ref);
          runJs("window.__fwNative(" + JSONObject.quote(id) + ",true," + JSONObject.quote(Base64.encodeToString(r.body, Base64.NO_WRAP)) + ")");
        } catch (Exception e) {
          runJs("window.__fwNative(" + JSONObject.quote(id) + ",false," + JSONObject.quote(String.valueOf(e.getMessage())) + ")");
        }
      }).start();
    }
    @JavascriptInterface public boolean isApp() { return true; }
    /* Make a tab from YouTube: {url, dur (ms), title, resume}. Returns "" when it started, or why it can't. */
    @JavascriptInterface public String ytRecord(final String json) {
      if (Build.VERSION.SDK_INT < 29) return "old";
      if (RecService.inst != null) return "busy";
      try { final JSONObject o = new JSONObject(json); RecService.result = null; RecService.markReset(MainActivity.this);
        RecService.mark(MainActivity.this, "asked to record, " + Build.MANUFACTURER + " " + Build.MODEL + " SDK " + Build.VERSION.SDK_INT); ui.post(() -> { pendingRec = o; recBegin(); }); return ""; }
      catch (Exception e) { return "bad"; }
    }
    @JavascriptInterface public String lastCrash() {
      File f = new File(getFilesDir(), "crash.txt"); if (!f.exists()) return "";
      byte[] b = read(f); f.delete(); try { return b == null ? "" : new String(b, "UTF-8"); } catch (Exception e) { return ""; }
    }
    @JavascriptInterface public String recTrace() { return RecService.trace(MainActivity.this); }
    @JavascriptInterface public String recStatus() { return RecService.inst != null ? RecService.status.toString() : "{\"state\":\"idle\"}"; }
    @JavascriptInterface public String recResult() { JSONObject r = RecService.result; return r == null ? "" : r.toString(); }
    @JavascriptInterface public void recClear() { RecService.result = null; }
    @JavascriptInterface public void recStop(final boolean cancel) {
      if (RecService.inst == null) return;
      try { startService(new Intent(MainActivity.this, RecService.class).setAction(cancel ? RecService.CANCEL : RecService.STOP)); } catch (Exception e) { }
    }
    @JavascriptInterface public void openPanelUrl(final String url) { ui.post(() -> openPanel(url)); }
    @JavascriptInterface public String nowPlaying() {
      try {
        android.media.session.MediaSessionManager msm = (android.media.session.MediaSessionManager) getSystemService(MEDIA_SESSION_SERVICE);
        java.util.List<android.media.session.MediaController> list = msm.getActiveSessions(new android.content.ComponentName(MainActivity.this, NowPlayingService.class));
        android.media.session.MediaController best = null;
        for (android.media.session.MediaController c : list) {
          android.media.session.PlaybackState st = c.getPlaybackState();
          boolean playing = st != null && st.getState() == android.media.session.PlaybackState.STATE_PLAYING;
          if (playing && (best == null || c.getPackageName().contains("spotify"))) best = c;
          else if (best == null) best = c;
        }
        if (best == null || best.getMetadata() == null) return "";
        current = best;
        android.media.MediaMetadata md = best.getMetadata();
        android.media.session.PlaybackState st = best.getPlaybackState();
        boolean playing = st != null && st.getState() == android.media.session.PlaybackState.STATE_PLAYING;
        long pos = 0;
        if (st != null) {
          pos = st.getPosition();
          if (playing) pos += (long) ((android.os.SystemClock.elapsedRealtime() - st.getLastPositionUpdateTime()) * st.getPlaybackSpeed());
        }
        JSONObject o = new JSONObject();
        o.put("title", md.getString(android.media.MediaMetadata.METADATA_KEY_TITLE));
        o.put("artist", md.getString(android.media.MediaMetadata.METADATA_KEY_ARTIST));
        o.put("album", md.getString(android.media.MediaMetadata.METADATA_KEY_ALBUM));
        o.put("dur", md.getLong(android.media.MediaMetadata.METADATA_KEY_DURATION));
        o.put("pos", pos);
        o.put("app", best.getPackageName());
        o.put("playing", playing);
        return o.toString();
      } catch (SecurityException e) {
        return "perm";
      } catch (Exception e) {
        return "";
      }
    }
    @JavascriptInterface public boolean transport(final String action, final double ms) {
      final android.media.session.MediaController c = current;
      if (c == null) return false;
      ui.post(() -> {
        try {
          android.media.session.MediaController.TransportControls t = c.getTransportControls();
          if ("play".equals(action)) t.play();
          else if ("pause".equals(action)) t.pause();
          else if ("seek".equals(action)) t.seekTo((long) Math.max(0, ms));
          else if ("next".equals(action)) t.skipToNext();
          else if ("prev".equals(action)) t.skipToPrevious();
        } catch (Exception e) { }
      });
      return true;
    }
    /* press a media key (play, pause, next, previous). It reaches the last music app you used, even when
       Spotify has gone quiet, so Fretwork can wake it back up without leaving the app. */
    @JavascriptInterface public boolean mediaKey(final String key) {
      try {
        int code = "play".equals(key) ? android.view.KeyEvent.KEYCODE_MEDIA_PLAY : "pause".equals(key) ? android.view.KeyEvent.KEYCODE_MEDIA_PAUSE
            : "next".equals(key) ? android.view.KeyEvent.KEYCODE_MEDIA_NEXT : "prev".equals(key) ? android.view.KeyEvent.KEYCODE_MEDIA_PREVIOUS : android.view.KeyEvent.KEYCODE_MEDIA_PLAY_PAUSE;
        android.media.AudioManager am = (android.media.AudioManager) getSystemService(AUDIO_SERVICE);
        am.dispatchMediaKeyEvent(new android.view.KeyEvent(android.view.KeyEvent.ACTION_DOWN, code));
        am.dispatchMediaKeyEvent(new android.view.KeyEvent(android.view.KeyEvent.ACTION_UP, code));
        return true;
      } catch (Exception e) { return false; }
    }
    /* open the music app on its now-playing screen (falls back to opening Spotify) */
    @JavascriptInterface public void openPlayer() {
      ui.post(() -> {
        try {
          android.media.session.MediaController c = current;
          if (c != null && c.getSessionActivity() != null) { c.getSessionActivity().send(); return; }
        } catch (Exception e) { }
        try {
          Intent i = getPackageManager().getLaunchIntentForPackage("com.spotify.music");
          if (i != null) { startActivity(i); return; }
          startActivity(new Intent(Intent.ACTION_VIEW, Uri.parse("spotify:")));
        } catch (Exception e) { }
      });
    }
    @JavascriptInterface public void openNowPlayingSettings() {
      ui.post(() -> {
        try { startActivity(new Intent("android.settings.ACTION_NOTIFICATION_LISTENER_SETTINGS")); }
        catch (Exception e) { }
      });
    }
    @JavascriptInterface public void keepAwake(final boolean on) {
      ui.post(() -> {
        if (on) getWindow().addFlags(android.view.WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
        else getWindow().clearFlags(android.view.WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
      });
    }
    @JavascriptInterface public void setLandscape(final boolean on) {
      ui.post(() -> setRequestedOrientation(on ? android.content.pm.ActivityInfo.SCREEN_ORIENTATION_SENSOR_LANDSCAPE
          : android.content.pm.ActivityInfo.SCREEN_ORIENTATION_UNSPECIFIED));
    }
    @JavascriptInterface public void setImmersive(final boolean on) {
      ui.post(() -> {
        android.view.View d = getWindow().getDecorView();
        if (on) d.setSystemUiVisibility(android.view.View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY | android.view.View.SYSTEM_UI_FLAG_FULLSCREEN
            | android.view.View.SYSTEM_UI_FLAG_HIDE_NAVIGATION | android.view.View.SYSTEM_UI_FLAG_LAYOUT_STABLE
            | android.view.View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION | android.view.View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN);
        else d.setSystemUiVisibility(android.view.View.SYSTEM_UI_FLAG_LAYOUT_STABLE);
      });
    }
  }
}
