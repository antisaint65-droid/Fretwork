package com.antisaint.fretwork;

import android.webkit.CookieManager;
import java.io.ByteArrayOutputStream;
import java.io.InputStream;
import java.net.HttpURLConnection;
import java.net.URL;

/** Plain HTTP fetch that follows redirects and carries the in-app browser's cookies. */
final class Net {
  static String userAgent = "Mozilla/5.0 (Linux; Android 14) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0 Mobile Safari/537.36";

  static final class Result { byte[] body; String disposition; String mime; String finalUrl; }

  static Result get(String address, String referer) throws Exception {
    String current = address;
    for (int hop = 0; hop < 8; hop++) {
      URL url = new URL(current);
      HttpURLConnection c = (HttpURLConnection) url.openConnection();
      c.setInstanceFollowRedirects(false);
      c.setConnectTimeout(15000);
      c.setReadTimeout(20000);
      c.setRequestProperty("User-Agent", userAgent);
      c.setRequestProperty("Accept", "*/*");
      if (referer != null) c.setRequestProperty("Referer", referer);
      String cookies = CookieManager.getInstance().getCookie(current);
      if (cookies != null) c.setRequestProperty("Cookie", cookies);
      int code = c.getResponseCode();
      if (code >= 300 && code < 400) {
        String loc = c.getHeaderField("Location");
        c.disconnect();
        if (loc == null) throw new Exception("redirect without location");
        current = new URL(url, loc).toString();
        continue;
      }
      if (code >= 400) { c.disconnect(); throw new Exception("HTTP " + code); }
      InputStream in = c.getInputStream();
      ByteArrayOutputStream out = new ByteArrayOutputStream();
      byte[] buf = new byte[16384];
      int n;
      while ((n = in.read(buf)) > 0) out.write(buf, 0, n);
      in.close();
      Result r = new Result();
      r.body = out.toByteArray();
      r.disposition = c.getHeaderField("Content-Disposition");
      r.mime = c.getContentType();
      r.finalUrl = current;
      c.disconnect();
      return r;
    }
    throw new Exception("too many redirects");
  }
}
