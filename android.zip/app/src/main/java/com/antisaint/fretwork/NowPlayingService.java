package com.antisaint.fretwork;

import android.service.notification.NotificationListenerService;

/** Turning this on in Android settings lets Fretwork read the song name from Spotify or any music app. */
public class NowPlayingService extends NotificationListenerService { }
