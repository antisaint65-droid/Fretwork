package com.antisaint.fretwork;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.app.Service;
import android.content.ComponentName;
import android.content.Intent;
import android.media.AudioAttributes;
import android.media.AudioFormat;
import android.media.AudioPlaybackCaptureConfiguration;
import android.media.AudioRecord;
import android.media.MediaCodec;
import android.media.MediaCodecInfo;
import android.media.MediaFormat;
import android.media.MediaMetadata;
import android.media.MediaMuxer;
import android.media.projection.MediaProjection;
import android.media.projection.MediaProjectionManager;
import android.media.session.MediaController;
import android.media.session.MediaSessionManager;
import android.media.session.PlaybackState;
import android.os.Build;
import android.os.Handler;
import android.os.IBinder;
import android.os.Looper;
import android.os.SystemClock;
import java.io.BufferedOutputStream;
import java.io.File;
import java.io.FileOutputStream;
import java.io.RandomAccessFile;
import java.nio.ByteBuffer;
import java.util.ArrayList;
import java.util.List;
import org.json.JSONObject;

/** Records the sound a browser is playing (YouTube in the in-app Chrome panel), not the mic.
    It watches the browser's play position so it knows exactly when the song starts and ends, skips ads,
    then cuts out just the song and saves it as a small .m4a for the lab. */
@android.annotation.TargetApi(29)
public class RecService extends Service {
  static final String CH = "rec", STOP = "stop", CANCEL = "cancel";
  static final int SR = 44100, NOTE = 7, DONE_NOTE = 8;
  static volatile RecService inst;
  static volatile JSONObject status = new JSONObject();
  static volatile JSONObject result = null;

  MediaProjection mp;
  AudioRecord ar;
  Thread worker;
  volatile boolean stopFlag = false, cancelFlag = false;
  long expectMs = 0;
  boolean resume = false;
  String title = "";
  final Handler ui = new Handler(Looper.getMainLooper());

  static final class Mark { long frame; String t; long dur, pos; boolean playing; }

  @Override public IBinder onBind(Intent i) { return null; }

  /* a short diary of each recording, so a crash report shows how far it got */
  static void mark(android.content.Context c, String what) {
    try { File d = new File(c.getFilesDir(), "rec"); d.mkdirs(); java.io.FileWriter w = new java.io.FileWriter(new File(d, "trace.txt"), true);
      w.write(new java.text.SimpleDateFormat("HH:mm:ss.SSS", java.util.Locale.US).format(new java.util.Date()) + " " + what + "\n"); w.close(); } catch (Throwable e) { }
  }
  static void markReset(android.content.Context c) { try { new File(new File(c.getFilesDir(), "rec"), "trace.txt").delete(); } catch (Throwable e) { } }
  static String trace(android.content.Context c) {
    try { byte[] b = MainActivity.read(new File(new File(c.getFilesDir(), "rec"), "trace.txt")); return b == null ? "" : new String(b, "UTF-8"); } catch (Throwable e) { return ""; }
  }

  static void setStatus(String state, long ms, double level, String note) {
    try { JSONObject o = new JSONObject(); o.put("state", state); o.put("ms", ms); o.put("level", level); o.put("note", note == null ? "" : note); status = o; } catch (Exception e) { }
  }

  @Override public int onStartCommand(Intent intent, int flags, int startId) {
    if (intent != null && STOP.equals(intent.getAction())) { stopFlag = true; return START_NOT_STICKY; }
    if (intent != null && CANCEL.equals(intent.getAction())) { cancelFlag = true; stopFlag = true; return START_NOT_STICKY; }
    if (worker != null) return START_NOT_STICKY;
    inst = this;
    result = null;
    mark(this, "service started");
    try {
      channel();
      Notification n = note("Recording the song for your tab", "Fretwork is listening to YouTube. Tap Stop if the song is over.", true);
      mark(this, "notification ready");
      if (Build.VERSION.SDK_INT >= 29) startForeground(NOTE, n, android.content.pm.ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PROJECTION);
      else startForeground(NOTE, n);
      mark(this, "foreground ok");
    } catch (Throwable e) {
      mark(this, "foreground FAILED: " + e);
      /* stay up long enough to report it (a service that never goes foreground would crash the app) */
      try { if (Build.VERSION.SDK_INT >= 30) { startForeground(NOTE, note("Recording didn't start", "Fretwork is reporting the problem.", false), android.content.pm.ServiceInfo.FOREGROUND_SERVICE_TYPE_MICROPHONE); mark(this, "fallback foreground ok"); } }
      catch (Throwable e2) { mark(this, "fallback FAILED: " + e2); }
      result = err("Android wouldn't start the recorder: " + e.getMessage());
      MainActivity a = MainActivity.inst; if (a != null) a.runJs("window.fretworkRecDone&&window.fretworkRecDone()");
      inst = null; try { stopForeground(true); } catch (Throwable e3) { } stopSelf();
      return START_NOT_STICKY;
    }
    try {
      expectMs = intent.getLongExtra("dur", 0);
      resume = intent.getBooleanExtra("resume", false);
      title = intent.getStringExtra("title");
      if (title == null) title = "";
      int code = intent.getIntExtra("code", 0);
      Intent data = intent.getParcelableExtra("data");
      MediaProjectionManager mpm = (MediaProjectionManager) getSystemService(MEDIA_PROJECTION_SERVICE);
      mark(this, "result code " + code + ", data " + (data != null));
      mp = mpm.getMediaProjection(code, data);
      mark(this, "projection " + (mp != null));
      if (mp == null) throw new Exception("Android didn't allow the recording.");
      mp.registerCallback(new MediaProjection.Callback() { @Override public void onStop() { stopFlag = true; } }, ui);
      AudioPlaybackCaptureConfiguration cfg = new AudioPlaybackCaptureConfiguration.Builder(mp)
          .addMatchingUsage(AudioAttributes.USAGE_MEDIA).addMatchingUsage(AudioAttributes.USAGE_UNKNOWN).addMatchingUsage(AudioAttributes.USAGE_GAME).build();
      int min = AudioRecord.getMinBufferSize(SR, AudioFormat.CHANNEL_IN_STEREO, AudioFormat.ENCODING_PCM_16BIT);
      ar = new AudioRecord.Builder()
          .setAudioFormat(new AudioFormat.Builder().setEncoding(AudioFormat.ENCODING_PCM_16BIT).setSampleRate(SR).setChannelMask(AudioFormat.CHANNEL_IN_STEREO).build())
          .setBufferSizeInBytes(Math.max(min * 4, SR * 4 / 2))
          .setAudioPlaybackCaptureConfig(cfg).build();
      mark(this, "recorder built, state " + ar.getState());
      ar.startRecording();
      mark(this, "recording, state " + ar.getRecordingState());
    } catch (Throwable e) {
      mark(this, "start FAILED: " + e);
      finish(err("Couldn't start recording: " + e.getMessage()), false);
      return START_NOT_STICKY;
    }
    setStatus("rec", 0, 0, "");
    worker = new Thread(this::loop, "fw-rec");
    worker.start();
    return START_NOT_STICKY;
  }

  /* ---------- the recording loop ---------- */
  void loop() {
    File dir = new File(getFilesDir(), "rec"); dir.mkdirs();
    File pcm = new File(dir, "cap.pcm");
    List<Mark> marks = new ArrayList<>();
    final int block = SR / 4;                       /* 0.25 s of stereo frames */
    short[] buf = new short[block * 2];
    byte[] bytes = new byte[block * 4];
    long frames = 0, loudBlocks = 0, quietRun = 0, firstLoud = -1, lastLoud = -1;
    String target = null; long tDur = 0, tMaxPos = 0;
    boolean sawSession = false, ended = false;
    long cap = expectMs > 0 ? expectMs + 180000 : 15 * 60000;
    cap = Math.min(cap, 20 * 60000);
    try (BufferedOutputStream out = new BufferedOutputStream(new FileOutputStream(pcm), 1 << 16)) {
      while (!stopFlag) {
        int got = 0;
        while (got < buf.length && !stopFlag) { int n = ar.read(buf, got, buf.length - got); if (n < 0) throw new Exception("read " + n); got += n; }
        if (got <= 0) break;
        double sum = 0;
        for (int i = 0; i < got; i++) { short s = buf[i]; sum += (double) s * s; bytes[2 * i] = (byte) s; bytes[2 * i + 1] = (byte) (s >> 8); }
        out.write(bytes, 0, got * 2);
        double rms = Math.sqrt(sum / Math.max(1, got)) / 32768.0;
        long blockIdx = frames / block;
        frames += got / 2;
        boolean loud = rms > 0.004;
        if (loud) { loudBlocks++; quietRun = 0; if (firstLoud < 0) firstLoud = blockIdx; lastLoud = blockIdx; } else quietRun++;
        long ms = frames * 1000 / SR;

        /* what the browser says it's playing */
        Mark m = browser();
        if (m != null) {
          sawSession = true; m.frame = frames; marks.add(m);
          boolean fits = m.dur > 30000 && (expectMs <= 0 || Math.abs(m.dur - expectMs) <= Math.max(15000, expectMs / 8));
          if (target == null && fits && m.playing) { target = m.t; tDur = m.dur; }
          if (target != null && target.equals(m.t)) {
            tMaxPos = Math.max(tMaxPos, m.pos);
            if (m.pos >= tDur - 900 && tMaxPos > tDur / 2) ended = true;
          } else if (target != null && m.t != null && !m.t.equals(target) && tMaxPos > tDur * 0.8) ended = true;   /* autoplay moved on */
        }
        if (target != null && tMaxPos > tDur * 0.8 && quietRun >= 12) ended = true;                       /* song over, gone quiet */
        if (target == null && !sawSession) {                                                                /* no browser info: go by the sound */
          long need = expectMs > 0 ? Math.max(20000, expectMs * 6 / 10) : 20000;
          if (loudBlocks * 250 >= need && quietRun >= 24) ended = true;
        }
        if (ms >= cap) ended = true;
        setStatus("rec", ms, rms, target != null ? "song" : loudBlocks > 0 ? "sound" : "waiting");
        if (ended) break;
      }
    } catch (Throwable e) {
      mark(this, "loop FAILED: " + e);
      if (!cancelFlag) { finish(err("Recording stopped: " + e.getMessage()), false); return; }
    }
    try { ar.stop(); } catch (Exception e) { }
    try { ar.release(); } catch (Exception e) { }
    try { if (mp != null) mp.stop(); } catch (Exception e) { }
    pauseBrowser();
    if (cancelFlag) { pcm.delete(); finish(null, false); return; }
    if (loudBlocks < 8) { pcm.delete(); finish(err("silent"), true); return; }

    /* cut out just the song */
    long start, end; String how;
    long tStart = Long.MAX_VALUE, tEnd = -1;
    if (target != null) for (Mark m : marks) if (target.equals(m.t) && m.playing && m.pos > 0) {
      tStart = Math.min(tStart, m.frame - m.pos * SR / 1000); tEnd = Math.max(tEnd, m.frame);
    }
    if (tEnd > 0) { start = Math.max(0, tStart - SR / 5); end = Math.min(frames, tEnd + SR / 2); how = "player"; }
    else { start = Math.max(0, firstLoud * block - SR / 3); end = Math.min(frames, (lastLoud + 1) * block + SR); how = "sound"; }
    if (end - start < SR * 10) { start = 0; end = frames; how = "all"; }
    setStatus("save", (end - start) * 1000 / SR, 0, "");
    File m4a = new File(dir, "latest.m4a");
    mark(this, "saving " + how + " " + (end - start) / SR + "s of " + frames / SR + "s, loud blocks " + loudBlocks + ", browser " + sawSession + ", target " + (target != null));
    try { encode(pcm, start, end, m4a); mark(this, "saved " + m4a.length() + " bytes"); }
    catch (Throwable e) { pcm.delete(); finish(err("Couldn't save the recording: " + e.getMessage()), true); return; }
    pcm.delete();
    try {
      JSONObject o = new JSONObject();
      o.put("ok", true); o.put("ms", (end - start) * 1000 / SR); o.put("bytes", m4a.length()); o.put("how", how);
      o.put("video", target == null ? "" : target); o.put("at", System.currentTimeMillis());
      finish(o, true);
    } catch (Exception e) { finish(err("save"), true); }
  }

  /* ---------- the browser's media session (needs the now-playing access the app already asks for) ---------- */
  MediaController browserCtl;
  Mark browser() {
    try {
      MediaSessionManager msm = (MediaSessionManager) getSystemService(MEDIA_SESSION_SERVICE);
      List<MediaController> list = msm.getActiveSessions(new ComponentName(this, NowPlayingService.class));
      MediaController best = null;
      for (MediaController c : list) {
        String p = c.getPackageName();
        if (p.equals(getPackageName()) || p.contains("spotify")) continue;
        if (p.contains("chrome") || p.contains("browser") || p.contains("youtube")) {
          PlaybackState st = c.getPlaybackState();
          if (best == null || (st != null && st.getState() == PlaybackState.STATE_PLAYING)) best = c;
        }
      }
      if (best == null) return null;
      browserCtl = best;
      MediaMetadata md = best.getMetadata();
      PlaybackState st = best.getPlaybackState();
      Mark m = new Mark();
      m.t = md == null ? "" : String.valueOf(md.getString(MediaMetadata.METADATA_KEY_TITLE));
      m.dur = md == null ? 0 : md.getLong(MediaMetadata.METADATA_KEY_DURATION);
      m.playing = st != null && st.getState() == PlaybackState.STATE_PLAYING;
      long pos = st == null ? 0 : st.getPosition();
      if (m.playing && st != null && st.getLastPositionUpdateTime() > 0) pos += (long) ((SystemClock.elapsedRealtime() - st.getLastPositionUpdateTime()) * st.getPlaybackSpeed());
      m.pos = Math.max(0, pos);
      return m;
    } catch (Throwable e) { return null; }
  }
  void pauseBrowser() { try { if (browserCtl != null) browserCtl.getTransportControls().pause(); } catch (Throwable e) { } }
  void resumeSpotify() {
    try {
      MediaSessionManager msm = (MediaSessionManager) getSystemService(MEDIA_SESSION_SERVICE);
      for (MediaController c : msm.getActiveSessions(new ComponentName(this, NowPlayingService.class)))
        if (c.getPackageName().contains("spotify")) { c.getTransportControls().play(); return; }
    } catch (Throwable e) { }
  }

  /* ---------- PCM slice -> AAC in an .m4a ---------- */
  static void encode(File pcm, long startFrame, long endFrame, File outFile) throws Exception {
    MediaFormat f = MediaFormat.createAudioFormat(MediaFormat.MIMETYPE_AUDIO_AAC, SR, 2);
    f.setInteger(MediaFormat.KEY_AAC_PROFILE, MediaCodecInfo.CodecProfileLevel.AACObjectLC);
    f.setInteger(MediaFormat.KEY_BIT_RATE, 160000);
    f.setInteger(MediaFormat.KEY_MAX_INPUT_SIZE, 16384);
    MediaCodec codec = MediaCodec.createEncoderByType(MediaFormat.MIMETYPE_AUDIO_AAC);
    codec.configure(f, null, null, MediaCodec.CONFIGURE_FLAG_ENCODE);
    codec.start();
    MediaMuxer mux = new MediaMuxer(outFile.getPath(), MediaMuxer.OutputFormat.MUXER_OUTPUT_MPEG_4);
    int track = -1; boolean muxing = false, inDone = false, outDone = false;
    MediaCodec.BufferInfo info = new MediaCodec.BufferInfo();
    try (RandomAccessFile in = new RandomAccessFile(pcm, "r")) {
      long pos = startFrame * 4, stop = Math.min(endFrame * 4, in.length());
      in.seek(pos);
      byte[] chunk = new byte[8192];
      while (!outDone) {
        if (!inDone) {
          int ix = codec.dequeueInputBuffer(10000);
          if (ix >= 0) {
            ByteBuffer b = codec.getInputBuffer(ix); b.clear();
            int want = (int) Math.min(Math.min(chunk.length, b.remaining()), stop - pos);
            want -= want % 4;
            long pts = (pos / 4 - startFrame) * 1000000L / SR;
            if (want <= 0) { codec.queueInputBuffer(ix, 0, 0, pts, MediaCodec.BUFFER_FLAG_END_OF_STREAM); inDone = true; }
            else { in.readFully(chunk, 0, want); b.put(chunk, 0, want); codec.queueInputBuffer(ix, 0, want, pts, 0); pos += want; }
          }
        }
        int ox = codec.dequeueOutputBuffer(info, 10000);
        if (ox == MediaCodec.INFO_OUTPUT_FORMAT_CHANGED) { track = mux.addTrack(codec.getOutputFormat()); mux.start(); muxing = true; }
        else if (ox >= 0) {
          ByteBuffer ob = codec.getOutputBuffer(ox);
          if ((info.flags & MediaCodec.BUFFER_FLAG_CODEC_CONFIG) != 0) info.size = 0;
          if (info.size > 0 && muxing) { ob.position(info.offset); ob.limit(info.offset + info.size); mux.writeSampleData(track, ob, info); }
          codec.releaseOutputBuffer(ox, false);
          if ((info.flags & MediaCodec.BUFFER_FLAG_END_OF_STREAM) != 0) outDone = true;
        }
      }
    } finally {
      try { codec.stop(); } catch (Exception e) { }
      codec.release();
      try { if (muxing) mux.stop(); } catch (Exception e) { }
      mux.release();
    }
  }

  static JSONObject err(String m) { try { JSONObject o = new JSONObject(); o.put("ok", false); o.put("err", m); return o; } catch (Exception e) { return null; } }

  /* done: tell the app, bring it back to the front, start Spotify again */
  void finish(JSONObject res, boolean bringBack) {
    result = res;
    mark(this, "finish " + (res == null ? "cancelled" : res.toString()));
    setStatus(res == null ? "idle" : "done", 0, 0, "");
    if (resume && res != null) resumeSpotify();
    MainActivity a = MainActivity.inst;
    if (a != null) a.runJs("window.fretworkRecDone&&window.fretworkRecDone()");
    if (bringBack && res != null) {
      Intent back = new Intent(this, MainActivity.class).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TOP | Intent.FLAG_ACTIVITY_SINGLE_TOP).putExtra("recDone", true);
      try { startActivity(back); } catch (Throwable e) { }
      try {
        PendingIntent pi = PendingIntent.getActivity(this, 3, back, PendingIntent.FLAG_IMMUTABLE | PendingIntent.FLAG_UPDATE_CURRENT);
        NotificationManager nm = (NotificationManager) getSystemService(NOTIFICATION_SERVICE);
        Notification.Builder b = Build.VERSION.SDK_INT >= 26 ? new Notification.Builder(this, CH) : new Notification.Builder(this);
        b.setSmallIcon(android.R.drawable.ic_media_play).setContentTitle(res.optBoolean("ok") ? "Song recorded" : "Recording didn't work")
            .setContentText("Tap to go back to Fretwork").setContentIntent(pi).setAutoCancel(true);
        nm.notify(DONE_NOTE, b.build());
      } catch (Throwable e) { }
    }
    worker = null;
    inst = null;
    try { if (Build.VERSION.SDK_INT >= 24) stopForeground(STOP_FOREGROUND_REMOVE); else stopForeground(true); } catch (Throwable e) { }
    stopSelf();
  }

  void channel() {
    if (Build.VERSION.SDK_INT < 26) return;
    NotificationManager nm = (NotificationManager) getSystemService(NOTIFICATION_SERVICE);
    if (nm.getNotificationChannel(CH) == null) nm.createNotificationChannel(new NotificationChannel(CH, "Song recording", NotificationManager.IMPORTANCE_DEFAULT));
  }
  Notification note(String t, String body, boolean withStop) {
    Notification.Builder b = Build.VERSION.SDK_INT >= 26 ? new Notification.Builder(this, CH) : new Notification.Builder(this);
    b.setSmallIcon(android.R.drawable.ic_btn_speak_now).setContentTitle(t).setContentText(body).setOngoing(true);
    if (withStop) {
      PendingIntent stop = PendingIntent.getService(this, 1, new Intent(this, RecService.class).setAction(STOP), PendingIntent.FLAG_IMMUTABLE);
      b.addAction(new Notification.Action.Builder(null, "Stop", stop).build());
    }
    return b.build();
  }
}
