#!/usr/bin/env bash
# Builds Fretwork.apk from the web app files in the repo root.
set -euo pipefail
here="$(cd "$(dirname "$0")" && pwd)"
root="$(cd "$here/.." && pwd)"
www="$here/app/src/main/assets/www"
mkdir -p "$www" "$here/app/src/main/res/mipmap-xxxhdpi"
cp "$root/index.html" "$www/"
for f in sw.js manifest.webmanifest icon-192.png icon-512.png; do [ -f "$root/$f" ] && cp "$root/$f" "$www/"; done
[ -d "$root/fonts" ] && cp -r "$root/fonts" "$www/" || true
[ -f "$root/paper.jpg" ] && cp "$root/paper.jpg" "$www/" || true
cp "$root/icon-192.png" "$here/app/src/main/res/mipmap-xxxhdpi/ic_launcher.png"
[ -f "$root/icon-fg.png" ] && cp "$root/icon-fg.png" "$here/app/src/main/res/mipmap-xxxhdpi/ic_launcher_foreground.png"
[ -f "$root/icon-bg.png" ] && cp "$root/icon-bg.png" "$here/app/src/main/res/mipmap-xxxhdpi/ic_launcher_background.png"
if [ ! -f "$root/icon-fg.png" ]; then rm -rf "$here/app/src/main/res/mipmap-anydpi-v26"; fi
cd "$here"
gradle --no-daemon -q assembleRelease
cp app/build/outputs/apk/release/app-release.apk "$root/Fretwork.apk"
echo "Built $root/Fretwork.apk"
